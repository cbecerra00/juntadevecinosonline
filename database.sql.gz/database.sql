-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema JdV_web
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema JdV_web
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `JdV_web` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `JdV_web` ;

-- -----------------------------------------------------
-- Table `JdV_web`.`Pais`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `JdV_web`.`Pais` (
  `Pais_ID` INT NOT NULL AUTO_INCREMENT,
  `Pais_Nombre` VARCHAR(50) NULL DEFAULT NULL,
  `Pais_Codigo` VARCHAR(2) NULL DEFAULT NULL,
  `Pais_Nombre_Ingles` VARCHAR(50) NULL DEFAULT NULL,
  PRIMARY KEY (`Pais_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 250
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `JdV_web`.`Region`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `JdV_web`.`Region` (
  `Regi_ID` INT NOT NULL AUTO_INCREMENT,
  `Regi_Nombre` VARCHAR(50) NULL DEFAULT NULL,
  `Pais_Pais_ID` INT NOT NULL,
  `Regi_CUT` INT NULL DEFAULT NULL,
  PRIMARY KEY (`Regi_ID`),
  CONSTRAINT `fk_Region_Pais1`
    FOREIGN KEY (`Pais_Pais_ID`)
    REFERENCES `JdV_web`.`Pais` (`Pais_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 16
DEFAULT CHARACTER SET = utf8mb3;

CREATE INDEX `fk_Region_Pais1_idx` ON `JdV_web`.`Region` (`Pais_Pais_ID` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `JdV_web`.`Provincia`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `JdV_web`.`Provincia` (
  `Prov_ID` INT NOT NULL AUTO_INCREMENT,
  `Prov_Nombre` VARCHAR(50) NULL DEFAULT NULL,
  `Prov_CUT` INT NULL DEFAULT NULL,
  `Region_Regi_ID` INT NOT NULL,
  PRIMARY KEY (`Prov_ID`),
  CONSTRAINT `fk_Provincia_Region1`
    FOREIGN KEY (`Region_Regi_ID`)
    REFERENCES `JdV_web`.`Region` (`Regi_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 55
DEFAULT CHARACTER SET = utf8mb3;

CREATE INDEX `fk_Provincia_Region1_idx` ON `JdV_web`.`Provincia` (`Region_Regi_ID` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `JdV_web`.`Ciudad`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `JdV_web`.`Ciudad` (
  `Ciud_ID` INT NOT NULL AUTO_INCREMENT,
  `Ciud_Nombre` VARCHAR(50) NULL DEFAULT NULL,
  `Ciud_CUT` INT NULL DEFAULT NULL,
  `Provincia_Prov_ID` INT NOT NULL,
  PRIMARY KEY (`Ciud_ID`),
  CONSTRAINT `fk_Ciudad_Provincia1`
    FOREIGN KEY (`Provincia_Prov_ID`)
    REFERENCES `JdV_web`.`Provincia` (`Prov_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 347
DEFAULT CHARACTER SET = utf8mb3;

CREATE INDEX `fk_Ciudad_Provincia1_idx` ON `JdV_web`.`Ciudad` (`Provincia_Prov_ID` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `JdV_web`.`JuntaDeVecinos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `JdV_web`.`JuntaDeVecinos` (
  `JdV_ID` INT NOT NULL AUTO_INCREMENT,
  `JdV_Nombre` VARCHAR(50) NULL DEFAULT NULL,
  `JdV_RUT` VARCHAR(8) NULL DEFAULT NULL,
  `JdV_DV` VARCHAR(1) NULL DEFAULT NULL,
  `JdV_Direccion` VARCHAR(100) NULL DEFAULT NULL,
  `Ciudad_Ciud_ID` INT NOT NULL,
  PRIMARY KEY (`JdV_ID`),
  CONSTRAINT `fk_Titular_Ciudad1`
    FOREIGN KEY (`Ciudad_Ciud_ID`)
    REFERENCES `JdV_web`.`Ciudad` (`Ciud_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 22727
DEFAULT CHARACTER SET = utf8mb3;

CREATE UNIQUE INDEX `Titu_RUT_UNIQUE` ON `JdV_web`.`JuntaDeVecinos` (`JdV_RUT` ASC) VISIBLE;

CREATE INDEX `fk_Titular_Ciudad1_idx` ON `JdV_web`.`JuntaDeVecinos` (`Ciudad_Ciud_ID` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `JdV_web`.`Tramite`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `JdV_web`.`Tramite` (
  `Tram_Codigo` INT NOT NULL AUTO_INCREMENT,
  `Tram_Nombre` VARCHAR(50) NULL DEFAULT NULL,
  PRIMARY KEY (`Tram_Codigo`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `JdV_web`.`Miembro`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `JdV_web`.`Miembro` (
  `Miem_ID` INT NOT NULL AUTO_INCREMENT,
  `Miem_1Nombre` VARCHAR(45) NULL,
  `Miem_2Nombre` VARCHAR(45) NULL,
  `Miem_1Apellido` VARCHAR(45) NULL,
  `Miem_2Apellido` VARCHAR(45) NULL,
  `Miem_Email` VARCHAR(45) NULL,
  `Miem_DireccionCalle` VARCHAR(45) NULL,
  `Miem_DireccionNro` VARCHAR(45) NULL,
  `Miem_DireccionDepto` VARCHAR(45) NULL,
  `Miem_RUT` VARCHAR(45) NULL,
  `JuntaDeVecinos_JdV_ID` INT NOT NULL,
  PRIMARY KEY (`Miem_ID`),
  CONSTRAINT `fk_Miembro_JuntaDeVecinos1`
    FOREIGN KEY (`JuntaDeVecinos_JdV_ID`)
    REFERENCES `JdV_web`.`JuntaDeVecinos` (`JdV_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_Miembro_JuntaDeVecinos1_idx` ON `JdV_web`.`Miembro` (`JuntaDeVecinos_JdV_ID` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `JdV_web`.`User`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `JdV_web`.`User` (
  `User_ID` INT NOT NULL AUTO_INCREMENT,
  `User_Email` VARCHAR(100) NOT NULL,
  `User_Password` VARCHAR(64) NOT NULL,
  `User_CreateTime` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  `Miembro_Miem_ID` INT NOT NULL,
  PRIMARY KEY (`User_ID`),
  CONSTRAINT `fk_User_Miembro1`
    FOREIGN KEY (`Miembro_Miem_ID`)
    REFERENCES `JdV_web`.`Miembro` (`Miem_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8mb3;

CREATE INDEX `fk_User_Miembro1_idx` ON `JdV_web`.`User` (`Miembro_Miem_ID` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `JdV_web`.`UserLog`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `JdV_web`.`UserLog` (
  `UL_Fecha` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  `UL_IP` VARCHAR(15) CHARACTER SET 'latin1' NULL DEFAULT NULL,
  `UL_Accion` VARCHAR(45) CHARACTER SET 'latin1' NULL DEFAULT NULL,
  `UL_User` VARCHAR(45) CHARACTER SET 'latin1' NULL DEFAULT NULL)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `JdV_web`.`TramiteMiembro`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `JdV_web`.`TramiteMiembro` (
  `TM_ID` VARCHAR(45) NOT NULL,
  `Tramite_Tram_Codigo` INT NOT NULL,
  `Miembro_Miem_ID` INT NOT NULL,
  `TM_Fecha` DATETIME NULL,
  PRIMARY KEY (`TM_ID`),
  CONSTRAINT `fk_TramiteMiembro_Tramite1`
    FOREIGN KEY (`Tramite_Tram_Codigo`)
    REFERENCES `JdV_web`.`Tramite` (`Tram_Codigo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TramiteMiembro_Miembro1`
    FOREIGN KEY (`Miembro_Miem_ID`)
    REFERENCES `JdV_web`.`Miembro` (`Miem_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE INDEX `fk_TramiteMiembro_Tramite1_idx` ON `JdV_web`.`TramiteMiembro` (`Tramite_Tram_Codigo` ASC) VISIBLE;

CREATE INDEX `fk_TramiteMiembro_Miembro1_idx` ON `JdV_web`.`TramiteMiembro` (`Miembro_Miem_ID` ASC) VISIBLE;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

